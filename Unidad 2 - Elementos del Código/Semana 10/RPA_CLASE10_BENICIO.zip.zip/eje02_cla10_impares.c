# include <stdio.h>
/ Resolucion y Problemas de  Algoritmos.
// Clase : 10
// Tema :Sentencia interacctia for
// Descripcion :    Secuencia de numero impares .
// Autor : Benicio Anahi 
// A�o : 2021

#include <stdlib.h>
#include <time.h>

int main (){
	
	int  x ;
	int suma, producto, cont;
	
	printf (" SECUENCIAS DE NUMEROS IMPARES\n ");
	
	for (x=1 ; x <12; x+=2){
	    printf ( "%3d", x);
	    	
	}
	 
	
	suma = 1+3+5+7+9+11;
	printf(" \n SUMA DE NUMEROS IMPARES Es : %d \n  ",suma);
	
	producto= producto * x ;
	
	printf(" EL PRODUCTO ES : ",producto);
	
		return 0;
}
