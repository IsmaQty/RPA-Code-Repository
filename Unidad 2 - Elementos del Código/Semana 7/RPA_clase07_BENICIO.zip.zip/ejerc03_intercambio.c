#include<stdio.h>



int main () //  FUNCION PRINCIPAL
 
 {
 	 int a= 2 , b= 10 , c=40, aux; // variables 
 	 
 	 printf(" Si a=2 , b=10  y c=40 INTERCAMBIANDO  QUERADRIA ASI");
 	 
 	
 	aux= a;
 	 a=b;
 	 b=c;
 	 c=a;
 	 
 	 
 	 printf ( "EL VALOR DE A ES ",b);
 	 printf ( "EL VALOR DE B ES ",c);
 	 printf ( "EL VALOR DE C ES ",a);
 	 
 	return 0;
 	  
}
