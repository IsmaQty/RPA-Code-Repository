#include <stdlib.h>
#include <time.h>
#include <stdio.h>
# define MAXV 15


void mostrar (int  vec[MAXV] );

int main()
{
   int  v[MAXV] ;
   int cont;
   int suma , tam ;
   srand (time (0));
    
    for (cont=0; cont<15; cont++)
	{
		v[cont]=12+rand ()% (35-12+1);
		
		printf ("%d\n",v[cont]);
		printf ( " LA SUMA TOTAL ES %d" ,suma );
		mostrar (v);
    	
	}
void mostrar (int  vec[MAXV] );	
 
	 for  ( cont=0 ; cont < tam ; cont++);
	 {
	 	 suma=vec[cont];
	 	 
	 }
}





